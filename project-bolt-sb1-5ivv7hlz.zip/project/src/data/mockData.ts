import { Product } from '../types';

export const mockProducts: Product[] = [
  {
    id: 1,
    name: "Yankees #99 Aaron Judge Jersey",
    team: "New York Yankees",
    sport: "Baseball",
    price: 129.99,
    salePrice: 99.99,
    image: "https://images.pexels.com/photos/163452/basketball-dunk-blue-game-163452.jpeg",
    rating: 4.8,
    sizes: ["S", "M", "L", "XL", "2XL"]
  },
  {
    id: 2,
    name: "Lakers #23 LeBron James Jersey",
    team: "Los Angeles Lakers",
    sport: "Basketball",
    price: 119.99,
    image: "https://images.pexels.com/photos/358042/pexels-photo-358042.jpeg",
    rating: 4.9,
    sizes: ["S", "M", "L", "XL", "2XL"]
  },
  {
    id: 3,
    name: "Chiefs #15 Patrick Mahomes Jersey",
    team: "Kansas City Chiefs",
    sport: "Football",
    price: 149.99,
    image: "https://images.pexels.com/photos/1618200/pexels-photo-1618200.jpeg",
    rating: 4.7,
    sizes: ["S", "M", "L", "XL", "2XL"]
  },
  {
    id: 4,
    name: "Warriors #30 Stephen Curry Jersey",
    team: "Golden State Warriors",
    sport: "Basketball",
    price: 109.99,
    salePrice: 89.99,
    image: "https://images.pexels.com/photos/358042/pexels-photo-358042.jpeg",
    rating: 4.6,
    sizes: ["S", "M", "L", "XL", "2XL"]
  },
  {
    id: 5,
    name: "Dodgers #50 Mookie Betts Jersey",
    team: "Los Angeles Dodgers",
    sport: "Baseball",
    price: 124.99,
    image: "https://images.pexels.com/photos/1661950/pexels-photo-1661950.jpeg",
    rating: 4.8,
    sizes: ["S", "M", "L", "XL", "2XL"]
  },
  {
    id: 6,
    name: "Cowboys #4 Dak Prescott Jersey",
    team: "Dallas Cowboys",
    sport: "Football",
    price: 114.99,
    image: "https://images.pexels.com/photos/1618200/pexels-photo-1618200.jpeg",
    rating: 4.5,
    sizes: ["S", "M", "L", "XL", "2XL"]
  },
  {
    id: 7,
    name: "Celtics #0 Jayson Tatum Jersey",
    team: "Boston Celtics",
    sport: "Basketball",
    price: 139.99,
    image: "https://images.pexels.com/photos/163452/basketball-dunk-blue-game-163452.jpeg",
    rating: 4.4,
    sizes: ["S", "M", "L", "XL", "2XL"]
  },
  {
    id: 8,
    name: "Red Sox #28 J.D. Martinez Jersey",
    team: "Boston Red Sox",
    sport: "Baseball",
    price: 119.99,
    salePrice: 95.99,
    image: "https://images.pexels.com/photos/1661950/pexels-photo-1661950.jpeg",
    rating: 4.7,
    sizes: ["S", "M", "L", "XL", "2XL"]
  },
  {
    id: 9,
    name: "Heat #22 Jimmy Butler Jersey",
    team: "Miami Heat",
    sport: "Basketball",
    price: 134.99,
    image: "https://images.pexels.com/photos/358042/pexels-photo-358042.jpeg",
    rating: 4.9,
    sizes: ["S", "M", "L", "XL", "2XL"]
  },
  {
    id: 10,
    name: "Rams #99 Aaron Donald Jersey",
    team: "Los Angeles Rams",
    sport: "Football",
    price: 144.99,
    image: "https://images.pexels.com/photos/1618200/pexels-photo-1618200.jpeg",
    rating: 4.6,
    sizes: ["S", "M", "L", "XL", "2XL"]
  },
  {
    id: 11,
    name: "Nets #7 Kevin Durant Jersey",
    team: "Brooklyn Nets",
    sport: "Basketball",
    price: 129.99,
    image: "https://images.pexels.com/photos/163452/basketball-dunk-blue-game-163452.jpeg",
    rating: 4.8,
    sizes: ["S", "M", "L", "XL", "2XL"]
  },
  {
    id: 12,
    name: "Astros #27 Jose Altuve Jersey",
    team: "Houston Astros",
    sport: "Baseball",
    price: 104.99,
    salePrice: 84.99,
    image: "https://images.pexels.com/photos/1661950/pexels-photo-1661950.jpeg",
    rating: 4.5,
    sizes: ["S", "M", "L", "XL", "2XL"]
  }
];