export interface Product {
  id: number;
  name: string;
  team: string;
  sport: string;
  price: number;
  salePrice?: number;
  image: string;
  rating: number;
  sizes: string[];
  description?: string;
  shopifyId?: string;
  handle?: string;
  vendor?: string;
  productType?: string;
  tags?: string;
  variants?: ShopifyVariant[];
  images?: ShopifyImage[];
}

export interface ShopifyVariant {
  id: string;
  title: string;
  price: number;
  compareAtPrice: number | null;
  sku: string;
  inventoryQuantity: number;
  available: boolean;
}

export interface ShopifyImage {
  id: string;
  src: string;
  alt: string;
}

export interface CartItem {
  id: number;
  name: string;
  price: number;
  image: string;
  size: string;
  quantity: number;
  shopifyVariantId?: string;
}