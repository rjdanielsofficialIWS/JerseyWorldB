import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Instagram, Twitter, Youtube, Mail, Phone, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black border-t border-gold/20 shadow-2xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4 animate-fade-in">
            <img 
              src="/WhatsApp Image 2025-07-05 at 15.47.34.jpeg" 
              alt="Jersey World B" 
              className="h-16 w-auto hover:scale-105 transition-transform duration-300"
            />
            <p className="text-gray-400 text-sm">
              Where legends are worn. Premium sports jerseys for true fans and athletes.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-gold transition-all duration-300 hover:scale-110 p-2 rounded-lg hover:bg-gold/10">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-gold transition-all duration-300 hover:scale-110 p-2 rounded-lg hover:bg-gold/10">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-gold transition-all duration-300 hover:scale-110 p-2 rounded-lg hover:bg-gold/10">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-gold transition-all duration-300 hover:scale-110 p-2 rounded-lg hover:bg-gold/10">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4 animate-fade-in-delay">
            <h3 className="text-white font-semibold text-lg">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/shop" className="text-gray-400 hover:text-gold transition-all duration-300 hover:translate-x-1">Shop All</Link></li>
              <li><Link to="/about" className="text-gray-400 hover:text-gold transition-all duration-300 hover:translate-x-1">About Us</Link></li>
              <li><Link to="/contact" className="text-gray-400 hover:text-gold transition-all duration-300 hover:translate-x-1">Contact</Link></li>
              <li><Link to="/size-guide" className="text-gray-400 hover:text-gold transition-all duration-300 hover:translate-x-1">Size Guide</Link></li>
            </ul>
          </div>

          {/* Customer Service */}
          <div className="space-y-4 animate-fade-in-delay-2">
            <h3 className="text-white font-semibold text-lg">Customer Service</h3>
            <ul className="space-y-2">
              <li><Link to="/shipping" className="text-gray-400 hover:text-gold transition-all duration-300 hover:translate-x-1">Shipping Info</Link></li>
              <li><Link to="/returns" className="text-gray-400 hover:text-gold transition-all duration-300 hover:translate-x-1">Returns</Link></li>
              <li><Link to="/faq" className="text-gray-400 hover:text-gold transition-all duration-300 hover:translate-x-1">FAQ</Link></li>
              <li><Link to="/track-order" className="text-gray-400 hover:text-gold transition-all duration-300 hover:translate-x-1">Track Order</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-4 animate-fade-in-delay-3">
            <h3 className="text-white font-semibold text-lg">Contact Info</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="h-4 w-4 text-gold" />
                <span className="text-gray-400 text-sm">+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-4 w-4 text-gold" />
                <span className="text-gray-400 text-sm">info@jerseyworldb.com</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="h-4 w-4 text-gold" />
                <span className="text-gray-400 text-sm">123 Sports Ave, City, State 12345</span>
              </div>
            </div>
          </div>
        </div>

        {/* Newsletter */}
        <div className="mt-12 pt-8 border-t border-gold/20">
          <div className="max-w-md mx-auto text-center animate-scale-in">
            <h3 className="text-white font-semibold text-lg mb-4">Stay Updated</h3>
            <p className="text-gray-400 text-sm mb-4">Get 10% off your first order when you subscribe!</p>
            <div className="flex">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 form-input rounded-r-none border-r-0"
              />
              <button className="btn-primary rounded-l-none px-6 py-2">
                Subscribe
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-8 pt-8 border-t border-gold/20 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">© 2025 Jersey World B. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <Link to="/privacy" className="text-gray-400 hover:text-gold text-sm transition-all duration-300 hover:translate-x-1">Privacy Policy</Link>
            <Link to="/terms" className="text-gray-400 hover:text-gold text-sm transition-all duration-300 hover:translate-x-1">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;