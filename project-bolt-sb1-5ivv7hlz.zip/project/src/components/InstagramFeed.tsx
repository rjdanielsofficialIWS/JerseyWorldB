import React from 'react';
import { Instagram } from 'lucide-react';

const InstagramFeed: React.FC = () => {
  return (
    <section className="py-20 bg-black relative">
      <div className="absolute inset-0 bg-gradient-radial from-gold/5 via-transparent to-transparent"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl font-bold text-white mb-8">Follow Us</h2>
          
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4 px-4">
            {/* Instagram */}
            <a
              href="https://instagram.com/jerseyworldb"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition-all duration-300 shadow-lg animate-fade-in w-full sm:w-auto justify-center"
            >
              <Instagram className="h-6 w-6" />
              <span className="text-base">@jerseyworldb</span>
            </a>

            {/* TikTok */}
            <a
              href="https://tiktok.com/@jerseyworldb"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-3 bg-gradient-to-r from-black to-gray-800 text-white px-6 py-3 rounded-lg font-semibold hover:from-gray-800 hover:to-black transition-all duration-300 shadow-lg border border-white/20 animate-fade-in w-full sm:w-auto justify-center"
            >
              <svg className="h-6 w-6" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-.88-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43V7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.43z"/>
              </svg>
              <span className="text-base">@jerseyworldb</span>
            </a>
          </div>

          <p className="text-gray-400 text-lg mt-8 animate-fade-in-delay">
            Follow us for the latest jersey drops, behind-the-scenes content, and exclusive deals!
          </p>
        </div>
      </div>
    </section>
  );
};

export default InstagramFeed;