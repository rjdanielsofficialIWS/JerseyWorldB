import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, ShoppingCart, Eye } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [selectedSize, setSelectedSize] = useState('M');
  const { addItem } = useCart();
  const { addItem: addToWishlist, removeItem: removeFromWishlist, isInWishlist } = useWishlist();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    
    // Find the shopify variant ID for the selected size
    let shopifyVariantId: string | undefined;
    
    if (product.variants && product.variants.length > 0) {
      // Try to find variant by size
      const variant = product.variants.find(v => 
        v.title === selectedSize || 
        (v.title && v.title.toLowerCase().includes(selectedSize.toLowerCase()))
      );
      
      if (variant) {
        shopifyVariantId = variant.id;
      } else {
        // Fallback to first available variant
        shopifyVariantId = product.variants[0].id;
      }
    }
    
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      size: selectedSize,
      quantity: 1,
      shopifyVariantId
    });
  };

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };

  return (
    <div
      className="group relative bg-gray-800 rounded-lg overflow-hidden hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-gold-lg animate-fade-in w-full"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <Link to={`/product/${product.id}`}>
        <div className="relative overflow-hidden aspect-square">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
          
          {/* Overlay */}
          <div className={`absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent transition-opacity duration-300 ${
            isHovered ? 'opacity-100' : 'opacity-0'
          }`} />

          {/* Quick Actions */}
          <div className={`absolute top-4 right-4 flex flex-col space-y-2 transition-all duration-500 ${
            isHovered ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-4'
          }`}>
            <button
              onClick={handleWishlistToggle}
              className={`p-2 rounded-full transition-all duration-300 hover:scale-110 ${
                isInWishlist(product.id)
                  ? 'bg-gold text-black'
                  : 'bg-white/20 backdrop-blur-sm text-white hover:bg-gold hover:text-black'
              }`}
            >
              <Heart className="h-4 w-4" />
            </button>
            <Link
              to={`/product/${product.id}`}
              className="p-2 rounded-full bg-white/20 backdrop-blur-sm text-white hover:bg-gold hover:text-black transition-all duration-300 hover:scale-110"
            >
              <Eye className="h-4 w-4" />
            </Link>
          </div>

          {/* Sale Badge */}
          {product.salePrice && (
            <div className="absolute top-4 left-4 bg-red-600 text-white px-3 py-1 rounded-full text-sm font-semibold animate-pulse shadow-lg">
              Sale
            </div>
          )}
        </div>

        <div className="p-4 flex flex-col h-full">
          <h3 className="text-white font-semibold text-lg mb-2 group-hover:text-gold transition-all duration-300 line-clamp-2">
            {product.name}
          </h3>
          <p className="text-gray-400 text-sm mb-2">{product.team}</p>
          
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              {product.salePrice ? (
                <>
                  <span className="text-gold font-bold text-lg">${product.salePrice}</span>
                  <span className="text-gray-400 line-through">${product.price}</span>
                </>
              ) : (
                <span className="text-gold font-bold text-lg">${product.price}</span>
              )}
            </div>
            <div className="flex items-center">
              <span className="text-yellow-400">★</span>
              <span className="text-gray-400 text-sm ml-1">{product.rating}</span>
            </div>
          </div>

          {/* Size Selector and Add to Cart */}
          <div className="flex items-center justify-between gap-2 mt-auto pt-2 border-t border-gray-700">
            {/* Compact Size Selector */}
            <div className="flex items-center space-x-1 flex-1">
              <svg className="h-3 w-3 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 13v6M8 13v6M12 13v6" />
              </svg>
              <span className="text-xs text-gray-400">Size:</span>
              <select
                value={selectedSize}
                onChange={(e) => setSelectedSize(e.target.value)}
                className="bg-gray-700 text-white text-xs rounded px-2 py-1 border border-gray-600 focus:ring-1 focus:ring-gold focus:border-gold w-14 hover:bg-gray-600 transition-colors"
                onClick={(e) => e.preventDefault()}
                title="Select size"
                aria-label="Select size"
              >
                {product.sizes.map((size) => (
                  <option key={size} value={size}>{size}</option>
                ))}
              </select>
            </div>
            
            {/* Compact Add to Cart Button */}
            <button
              onClick={handleAddToCart}
              className="bg-gold text-black rounded px-3 py-2 hover:bg-gold/90 transition-all duration-300 flex items-center justify-center space-x-1 hover:scale-105 active:scale-95 shadow-md hover:shadow-lg"
              title="Add to cart"
              aria-label="Add to cart"
            >
              <ShoppingCart className="h-4 w-4" />
              <span className="text-xs font-semibold">Add</span>
            </button>
          </div>
        </div>
      </Link>
    </div>
  );
};

export default ProductCard;