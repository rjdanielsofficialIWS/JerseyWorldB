import React from 'react';

const LoadingSpinner: React.FC = () => {
  return (
    <div className="flex items-center justify-center py-12">
      <div className="relative">
        <div className="w-16 h-16 border-4 border-gray-600 border-t-gold rounded-full animate-spin"></div>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-8 h-8 bg-gold rounded-full animate-pulse"></div>
        </div>
      </div>
      <div className="ml-4">
        <p className="text-white text-lg font-semibold">Loading products...</p>
        <p className="text-gray-400 text-sm">Fetching from Shopify store</p>
      </div>
    </div>
  );
};

export default LoadingSpinner;