import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const HeroSection: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  return (
    <>
      {/* Banner Image Section */}
      <section className="relative h-[50vh] md:h-[70vh] lg:h-screen overflow-hidden animate-fade-in">
        <img
          src="/Jerseyworldbbanner.jpg"
          alt="Jersey World B Banner"
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-700"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>
      </section>

      {/* Shop Now Button Section */}
      <section className="py-20 bg-black relative">
        <div className="absolute inset-0 bg-gradient-radial from-gold/5 via-transparent to-transparent"></div>
        <div className="text-center relative z-10 animate-scale-in">
          <Link
            to="/shop"
            className="inline-block btn-primary px-16 py-8 text-2xl shadow-gold-xl hover:shadow-gold-xl hover:animate-pulse-gold"
          >
            Shop Now
          </Link>
        </div>
      </section>
    </>
  );
};

export default HeroSection;