import React, { useState } from 'react';
import { Mail } from 'lucide-react';

const NewsletterSignup: React.FC = () => {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle newsletter signup
    setIsSubscribed(true);
    setEmail('');
    setTimeout(() => setIsSubscribed(false), 3000);
  };

  return (
    <section className="py-20 bg-gradient-to-r from-gold/10 to-gold/5 relative">
      <div className="absolute inset-0 bg-gradient-radial from-gold/10 via-transparent to-transparent"></div>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="glass rounded-2xl p-8 md:p-12 animate-scale-in">
          <Mail className="h-16 w-16 text-gold mx-auto mb-6 animate-pulse-gold" />
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 gradient-text">
            Join the Champions Circle
          </h2>
          <p className="text-gray-300 text-lg mb-8 max-w-2xl mx-auto">
            Get exclusive access to new releases, special offers, and insider news. 
            Plus, enjoy 10% off your first order when you subscribe!
          </p>

          {isSubscribed ? (
            <div className="bg-green-600/20 border border-green-600/50 rounded-lg p-4 text-green-400 animate-fade-in">
              Thank you for subscribing! Check your email for your 10% discount code.
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="max-w-md mx-auto">
              <div className="flex flex-col sm:flex-row gap-4">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address"
                  required
                  className="flex-1 form-input"
                />
                <button
                  type="submit"
                  className="btn-primary px-8 py-3"
                >
                  Subscribe
                </button>
              </div>
              <p className="text-gray-400 text-sm mt-4">
                By subscribing, you agree to our Privacy Policy and Terms of Service.
              </p>
            </form>
          )}
        </div>
      </div>
    </section>
  );
};

export default NewsletterSignup;