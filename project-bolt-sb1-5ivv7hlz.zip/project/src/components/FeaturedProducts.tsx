import React from 'react';
import ProductCard from './ProductCard';
import { useProducts } from '../hooks/useProducts';
import LoadingSpinner from './LoadingSpinner';

const FeaturedProducts: React.FC = () => {
  const { products, loading } = useProducts();
  const featuredProducts = products.slice(0, 6);

  if (loading) {
    return (
      <section className="py-16 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <LoadingSpinner />
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 bg-black relative">
      <div className="absolute inset-0 bg-gradient-radial from-gold/5 via-transparent to-transparent"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl font-bold text-white mb-4">Featured Products</h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Discover our most popular jerseys worn by champions and loved by fans worldwide
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredProducts.map((product, index) => (
            <div key={product.id} className={`animate-fade-in-delay-${Math.min(index + 1, 3)}`}>
              <ProductCard product={product} />
            </div>
          ))}
        </div>

        <div className="text-center mt-16 animate-scale-in">
          <a
            href="/shop"
            className="inline-block btn-secondary px-12 py-4 text-lg"
          >
            View All Products
          </a>
        </div>
      </div>
    </section>
  );
};

export default FeaturedProducts;