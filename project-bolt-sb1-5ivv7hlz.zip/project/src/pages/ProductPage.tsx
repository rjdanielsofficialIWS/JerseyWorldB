import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Heart, ShoppingCart, Share2, Star, ChevronLeft, ChevronRight } from 'lucide-react';
import { useProduct, useProducts } from '../hooks/useProducts';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import ProductCard from '../components/ProductCard';
import LoadingSpinner from '../components/LoadingSpinner';

const ProductPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { product, loading: productLoading, error: productError } = useProduct(parseInt(id || '0'));
  const { products } = useProducts();
  const [selectedSize, setSelectedSize] = useState('M');
  const [quantity, setQuantity] = useState(1);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [activeTab, setActiveTab] = useState('description');

  const { addItem } = useCart();
  const { addItem: addToWishlist, removeItem: removeFromWishlist, isInWishlist } = useWishlist();

  if (productLoading) {
    return (
      <div className="min-h-screen bg-gray-900 pt-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <LoadingSpinner />
        </div>
      </div>
    );
  }

  if (productError || !product) {
    return (
      <div className="min-h-screen bg-gray-900 pt-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center py-12">
            <p className="text-red-400 text-lg mb-4">
              {productError || 'Product not found'}
            </p>
            <a
              href="/shop"
              className="bg-gold text-black px-6 py-3 rounded-lg font-semibold hover:bg-gold/90 transition-colors duration-300"
            >
              Back to Shop
            </a>
          </div>
        </div>
      </div>
    );
  }
  
  const productImages = product.images && product.images.length > 0 
    ? product.images.map(img => img.src)
    : [product.image, product.image, product.image];
  const relatedProducts = products.filter(p => p.id !== product.id && p.sport === product.sport).slice(0, 4);

  const handleAddToCart = () => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.salePrice || product.price,
      image: product.image,
      size: selectedSize,
      quantity
    });
  };

  const handleWishlistToggle = () => {
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % productImages.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + productImages.length) % productImages.length);
  };

  return (
    <div className="min-h-screen bg-gray-900 pt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <nav className="mb-8">
          <ol className="flex items-center space-x-2 text-gray-400">
            <li><a href="/" className="hover:text-gold">Home</a></li>
            <li>/</li>
            <li><a href="/shop" className="hover:text-gold">Shop</a></li>
            <li>/</li>
            <li className="text-white">{product.name}</li>
          </ol>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="relative aspect-square bg-gray-800 rounded-lg overflow-hidden">
              <img
                src={productImages[currentImageIndex]}
                alt={product.name}
                className="w-full h-full object-cover"
              />
              
              {productImages.length > 1 && (
                <>
                  <button
                    onClick={prevImage}
                    className="absolute left-4 top-1/2 transform -translate-y-1/2 p-2 rounded-full bg-black/50 text-white hover:bg-black/70 transition-colors duration-300"
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </button>
                  <button
                    onClick={nextImage}
                    className="absolute right-4 top-1/2 transform -translate-y-1/2 p-2 rounded-full bg-black/50 text-white hover:bg-black/70 transition-colors duration-300"
                  >
                    <ChevronRight className="h-5 w-5" />
                  </button>
                </>
              )}
            </div>

            {/* Thumbnail Images */}
            <div className="flex space-x-2">
              {productImages.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentImageIndex(index)}
                  className={`w-20 h-20 rounded-lg overflow-hidden border-2 transition-colors duration-300 ${
                    index === currentImageIndex ? 'border-gold' : 'border-gray-600'
                  }`}
                >
                  <img src={image} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">{product.name}</h1>
              <p className="text-gold text-lg">{product.team} • {product.sport}</p>
            </div>

            {/* Rating */}
            <div className="flex items-center space-x-2">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < Math.floor(product.rating) ? 'text-yellow-400 fill-current' : 'text-gray-400'
                    }`}
                  />
                ))}
              </div>
              <span className="text-gray-400">({product.rating})</span>
            </div>

            {/* Price */}
            <div className="flex items-center space-x-3">
              {product.salePrice ? (
                <>
                  <span className="text-3xl font-bold text-gold">${product.salePrice}</span>
                  <span className="text-xl text-gray-400 line-through">${product.price}</span>
                  <span className="bg-red-600 text-white px-2 py-1 rounded text-sm font-semibold">
                    Save ${product.price - product.salePrice}
                  </span>
                </>
              ) : (
                <span className="text-3xl font-bold text-gold">${product.price}</span>
              )}
            </div>

            {/* Size Selection */}
            <div>
              <label className="block text-white font-semibold mb-3">Size</label>
              <div className="grid grid-cols-4 gap-2">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`py-2 px-4 rounded-lg border transition-colors duration-300 ${
                      selectedSize === size
                        ? 'border-gold bg-gold text-black'
                        : 'border-gray-600 text-white hover:border-gold'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity */}
            <div>
              <label className="block text-white font-semibold mb-3">Quantity</label>
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 rounded-lg bg-gray-800 text-white hover:bg-gray-700 transition-colors duration-300"
                >
                  -
                </button>
                <span className="text-white font-semibold text-lg w-8 text-center">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-10 h-10 rounded-lg bg-gray-800 text-white hover:bg-gray-700 transition-colors duration-300"
                >
                  +
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              <button
                onClick={handleAddToCart}
                className="w-full bg-gold text-black py-3 rounded-lg font-semibold hover:bg-gold/90 transition-colors duration-300 flex items-center justify-center space-x-2"
              >
                <ShoppingCart className="h-5 w-5" />
                <span>Add to Cart</span>
              </button>
              
              <div className="flex space-x-3">
                <button
                  onClick={handleWishlistToggle}
                  className={`flex-1 py-3 rounded-lg font-semibold transition-colors duration-300 flex items-center justify-center space-x-2 ${
                    isInWishlist(product.id)
                      ? 'bg-red-600 text-white'
                      : 'bg-gray-800 text-white hover:bg-gray-700'
                  }`}
                >
                  <Heart className="h-5 w-5" />
                  <span>{isInWishlist(product.id) ? 'Remove from Wishlist' : 'Add to Wishlist'}</span>
                </button>
                
                <button className="flex-1 bg-gray-800 text-white py-3 rounded-lg font-semibold hover:bg-gray-700 transition-colors duration-300 flex items-center justify-center space-x-2">
                  <Share2 className="h-5 w-5" />
                  <span>Share</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Product Details Tabs */}
        <div className="mb-16">
          <div className="border-b border-gray-700 mb-8">
            <nav className="flex space-x-8">
              {['description', 'sizing', 'reviews'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`py-4 px-2 border-b-2 font-medium capitalize transition-colors duration-300 ${
                    activeTab === tab
                      ? 'border-gold text-gold'
                      : 'border-transparent text-gray-400 hover:text-white'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </nav>
          </div>

          <div className="bg-gray-800 rounded-lg p-8">
            {activeTab === 'description' && (
              <div className="space-y-4">
                <h3 className="text-white font-semibold text-xl mb-4">Product Description</h3>
                <p className="text-gray-300 leading-relaxed">
                  This premium {product.name} jersey features authentic team colors and design elements. 
                  Crafted from high-quality moisture-wicking fabric, it provides superior comfort and 
                  durability for both game day and everyday wear.
                </p>
                <ul className="text-gray-300 space-y-2">
                  <li>• Official team colors and logos</li>
                  <li>• Moisture-wicking performance fabric</li>
                  <li>• Machine washable</li>
                  <li>• Athletic fit for optimal comfort</li>
                  <li>• Officially licensed product</li>
                </ul>
              </div>
            )}

            {activeTab === 'sizing' && (
              <div className="space-y-6">
                <h3 className="text-white font-semibold text-xl mb-4">Size Guide</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-gray-300">
                    <thead>
                      <tr className="border-b border-gray-600">
                        <th className="text-left py-2">Size</th>
                        <th className="text-left py-2">Chest (inches)</th>
                        <th className="text-left py-2">Length (inches)</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b border-gray-700">
                        <td className="py-2">S</td>
                        <td className="py-2">36-38</td>
                        <td className="py-2">28</td>
                      </tr>
                      <tr className="border-b border-gray-700">
                        <td className="py-2">M</td>
                        <td className="py-2">40-42</td>
                        <td className="py-2">29</td>
                      </tr>
                      <tr className="border-b border-gray-700">
                        <td className="py-2">L</td>
                        <td className="py-2">44-46</td>
                        <td className="py-2">30</td>
                      </tr>
                      <tr className="border-b border-gray-700">
                        <td className="py-2">XL</td>
                        <td className="py-2">48-50</td>
                        <td className="py-2">31</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'reviews' && (
              <div className="space-y-6">
                <h3 className="text-white font-semibold text-xl mb-4">Customer Reviews</h3>
                <div className="space-y-4">
                  {[1, 2, 3].map((review) => (
                    <div key={review} className="border-b border-gray-700 pb-4">
                      <div className="flex items-center space-x-2 mb-2">
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                          ))}
                        </div>
                        <span className="text-gray-400 text-sm">by Customer {review}</span>
                      </div>
                      <p className="text-gray-300">
                        Great quality jersey! The fit is perfect and the material feels premium. 
                        Highly recommend for any fan.
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-white mb-8">You May Also Like</h2>
            <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductPage;