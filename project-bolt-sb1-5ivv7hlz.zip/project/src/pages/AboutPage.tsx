import React from 'react';
import { Award, Users, Globe, Heart } from 'lucide-react';

const AboutPage: React.FC = () => {
  const stats = [
    { label: 'Happy Customers', value: '50,000+', icon: Users },
    { label: 'Countries Served', value: '25+', icon: Globe },
    { label: 'Years in Business', value: '10+', icon: Award },
    { label: 'Team Members', value: '50+', icon: Heart },
  ];

  const timeline = [
    { year: '2015', title: 'Company Founded', description: 'Started with a passion for authentic sports jerseys' },
    { year: '2017', title: 'First Major Partnership', description: 'Secured licensing deals with major sports leagues' },
    { year: '2019', title: 'International Expansion', description: 'Began shipping to customers worldwide' },
    { year: '2021', title: 'Custom Jersey Service', description: 'Launched personalized jersey customization' },
    { year: '2023', title: 'Sustainability Initiative', description: 'Introduced eco-friendly packaging and materials' },
    { year: '2025', title: 'Digital Innovation', description: 'Launched new e-commerce platform with enhanced features' },
  ];

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-black to-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Where Legends Are Worn
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            For over a decade, Jersey World B has been the premier destination for authentic sports jerseys, 
            connecting fans with their favorite teams and players through premium quality apparel.
          </p>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gold rounded-full mb-4">
                  <stat.icon className="h-8 w-8 text-black" />
                </div>
                <div className="text-3xl font-bold text-white mb-2">{stat.value}</div>
                <div className="text-gray-400">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-bold text-white mb-6">Our Story</h2>
              <div className="space-y-4 text-gray-300">
                <p>
                  Jersey World B was born from a simple passion: the love of sports and the desire to help 
                  fans express their team loyalty through authentic, high-quality jerseys. What started as 
                  a small operation has grown into a trusted global brand.
                </p>
                <p>
                  We believe that wearing your team's colors isn't just about fashion – it's about identity, 
                  community, and the shared experience of supporting something bigger than yourself. Every 
                  jersey we sell carries with it the hopes, dreams, and passion of fans worldwide.
                </p>
                <p>
                  Our commitment to authenticity, quality, and customer satisfaction has made us the go-to 
                  destination for sports enthusiasts who demand nothing but the best.
                </p>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/1618200/pexels-photo-1618200.jpeg"
                alt="Our Story"
                className="rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-20 bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-white text-center mb-12">Our Journey</h2>
          <div className="relative">
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gold"></div>
            <div className="space-y-12">
              {timeline.map((item, index) => (
                <div key={index} className={`flex items-center ${index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'}`}>
                  <div className={`w-1/2 ${index % 2 === 0 ? 'pr-8 text-right' : 'pl-8'}`}>
                    <div className="bg-gray-700 rounded-lg p-6">
                      <div className="text-gold font-bold text-xl mb-2">{item.year}</div>
                      <h3 className="text-white font-semibold text-lg mb-2">{item.title}</h3>
                      <p className="text-gray-300">{item.description}</p>
                    </div>
                  </div>
                  <div className="relative z-10 w-4 h-4 bg-gold rounded-full border-4 border-gray-900"></div>
                  <div className="w-1/2"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-white text-center mb-12">Our Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gold rounded-full mb-6">
                <Award className="h-10 w-10 text-black" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-4">Authenticity</h3>
              <p className="text-gray-300">
                Every jersey we sell is 100% authentic, sourced directly from official manufacturers 
                and licensed partners.
              </p>
            </div>
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gold rounded-full mb-6">
                <Heart className="h-10 w-10 text-black" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-4">Passion</h3>
              <p className="text-gray-300">
                We're not just selling jerseys – we're sharing our love for sports and helping fans 
                connect with their teams.
              </p>
            </div>
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gold rounded-full mb-6">
                <Users className="h-10 w-10 text-black" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-4">Community</h3>
              <p className="text-gray-300">
                We believe in building a community of sports fans who share the same passion and 
                dedication to their teams.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-white text-center mb-12">Meet Our Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[1, 2, 3].map((member) => (
              <div key={member} className="text-center">
                <img
                  src={`https://images.pexels.com/photos/1618200/pexels-photo-1618200.jpeg`}
                  alt={`Team Member ${member}`}
                  className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
                />
                <h3 className="text-xl font-semibold text-white mb-2">Team Member {member}</h3>
                <p className="text-gold mb-2">Position Title</p>
                <p className="text-gray-300 text-sm">
                  Passionate about sports and dedicated to providing the best customer experience.
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;