import React, { useState } from 'react';
import { User, Package, Heart, Settings, MapPin, CreditCard } from 'lucide-react';

const AccountPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('profile');

  const tabs = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'orders', label: 'Orders', icon: Package },
    { id: 'wishlist', label: 'Wishlist', icon: Heart },
    { id: 'addresses', label: 'Addresses', icon: MapPin },
    { id: 'payment', label: 'Payment', icon: CreditCard },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const orders = [
    { id: '12345', date: '2025-01-15', status: 'Delivered', total: 129.99 },
    { id: '12344', date: '2025-01-10', status: 'Shipped', total: 89.99 },
    { id: '12343', date: '2025-01-05', status: 'Processing', total: 199.99 },
  ];

  return (
    <div className="min-h-screen bg-gray-900 pt-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold text-white mb-8">My Account</h1>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-gray-800 rounded-lg p-6">
              <div className="text-center mb-6">
                <div className="w-20 h-20 bg-gold rounded-full mx-auto mb-4 flex items-center justify-center">
                  <User className="h-10 w-10 text-black" />
                </div>
                <h2 className="text-white font-semibold text-lg">John Doe</h2>
                <p className="text-gray-400">john.doe@email.com</p>
              </div>

              <nav className="space-y-2">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors duration-300 ${
                      activeTab === tab.id
                        ? 'bg-gold text-black'
                        : 'text-gray-400 hover:text-white hover:bg-gray-700'
                    }`}
                  >
                    <tab.icon className="h-5 w-5" />
                    <span>{tab.label}</span>
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Content */}
          <div className="lg:col-span-3">
            <div className="bg-gray-800 rounded-lg p-8">
              {activeTab === 'profile' && (
                <div>
                  <h2 className="text-2xl font-bold text-white mb-6">Profile Information</h2>
                  <form className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-white font-semibold mb-2">First Name</label>
                        <input
                          type="text"
                          defaultValue="John"
                          className="w-full bg-gray-700 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-gold"
                        />
                      </div>
                      <div>
                        <label className="block text-white font-semibold mb-2">Last Name</label>
                        <input
                          type="text"
                          defaultValue="Doe"
                          className="w-full bg-gray-700 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-gold"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-white font-semibold mb-2">Email</label>
                      <input
                        type="email"
                        defaultValue="john.doe@email.com"
                        className="w-full bg-gray-700 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-gold"
                      />
                    </div>
                    <div>
                      <label className="block text-white font-semibold mb-2">Phone</label>
                      <input
                        type="tel"
                        defaultValue="+1 (555) 123-4567"
                        className="w-full bg-gray-700 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-gold"
                      />
                    </div>
                    <button className="bg-gold text-black px-6 py-3 rounded-lg font-semibold hover:bg-gold/90 transition-colors duration-300">
                      Save Changes
                    </button>
                  </form>
                </div>
              )}

              {activeTab === 'orders' && (
                <div>
                  <h2 className="text-2xl font-bold text-white mb-6">Order History</h2>
                  <div className="space-y-4">
                    {orders.map((order) => (
                      <div key={order.id} className="bg-gray-700 rounded-lg p-6">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h3 className="text-white font-semibold">Order #{order.id}</h3>
                            <p className="text-gray-400">Placed on {order.date}</p>
                          </div>
                          <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                            order.status === 'Delivered' ? 'bg-green-600 text-white' :
                            order.status === 'Shipped' ? 'bg-blue-600 text-white' :
                            'bg-yellow-600 text-black'
                          }`}>
                            {order.status}
                          </span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-gold font-bold">${order.total}</span>
                          <button className="text-gold hover:text-gold/80 transition-colors duration-300">
                            View Details
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'wishlist' && (
                <div>
                  <h2 className="text-2xl font-bold text-white mb-6">My Wishlist</h2>
                  <p className="text-gray-400">Your wishlist is empty. Start adding items you love!</p>
                </div>
              )}

              {activeTab === 'addresses' && (
                <div>
                  <h2 className="text-2xl font-bold text-white mb-6">Saved Addresses</h2>
                  <div className="space-y-4">
                    <div className="bg-gray-700 rounded-lg p-6">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-white font-semibold mb-2">Home Address</h3>
                          <p className="text-gray-400">123 Main Street<br />New York, NY 10001<br />United States</p>
                        </div>
                        <button className="text-gold hover:text-gold/80 transition-colors duration-300">
                          Edit
                        </button>
                      </div>
                    </div>
                    <button className="w-full bg-gold text-black py-3 rounded-lg font-semibold hover:bg-gold/90 transition-colors duration-300">
                      Add New Address
                    </button>
                  </div>
                </div>
              )}

              {activeTab === 'payment' && (
                <div>
                  <h2 className="text-2xl font-bold text-white mb-6">Payment Methods</h2>
                  <div className="space-y-4">
                    <div className="bg-gray-700 rounded-lg p-6">
                      <div className="flex justify-between items-center">
                        <div>
                          <h3 className="text-white font-semibold">•••• •••• •••• 1234</h3>
                          <p className="text-gray-400">Expires 12/26</p>
                        </div>
                        <button className="text-gold hover:text-gold/80 transition-colors duration-300">
                          Remove
                        </button>
                      </div>
                    </div>
                    <button className="w-full bg-gold text-black py-3 rounded-lg font-semibold hover:bg-gold/90 transition-colors duration-300">
                      Add New Payment Method
                    </button>
                  </div>
                </div>
              )}

              {activeTab === 'settings' && (
                <div>
                  <h2 className="text-2xl font-bold text-white mb-6">Account Settings</h2>
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-white font-semibold mb-4">Email Preferences</h3>
                      <div className="space-y-3">
                        <label className="flex items-center space-x-3">
                          <input type="checkbox" defaultChecked className="rounded" />
                          <span className="text-gray-300">Order updates</span>
                        </label>
                        <label className="flex items-center space-x-3">
                          <input type="checkbox" defaultChecked className="rounded" />
                          <span className="text-gray-300">New product announcements</span>
                        </label>
                        <label className="flex items-center space-x-3">
                          <input type="checkbox" className="rounded" />
                          <span className="text-gray-300">Promotional emails</span>
                        </label>
                      </div>
                    </div>
                    <div>
                      <h3 className="text-white font-semibold mb-4">Change Password</h3>
                      <div className="space-y-4">
                        <input
                          type="password"
                          placeholder="Current password"
                          className="w-full bg-gray-700 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-gold"
                        />
                        <input
                          type="password"
                          placeholder="New password"
                          className="w-full bg-gray-700 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-gold"
                        />
                        <input
                          type="password"
                          placeholder="Confirm new password"
                          className="w-full bg-gray-700 text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-gold"
                        />
                        <button className="bg-gold text-black px-6 py-3 rounded-lg font-semibold hover:bg-gold/90 transition-colors duration-300">
                          Update Password
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountPage;