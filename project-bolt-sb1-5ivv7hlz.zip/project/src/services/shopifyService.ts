import { Product } from '../types';
import { mockProducts } from '../data/mockData';
import { supabase } from './supabaseClient';

const SHOPIFY_DOMAIN = import.meta.env.VITE_SHOPIFY_STOREFRONT_DOMAIN;
const SHOPIFY_ACCESS_TOKEN = import.meta.env.VITE_SHOPIFY_STOREFRONT_ACCESS_TOKEN;

export class ShopifyService {
  private static instance: ShopifyService;
  private cache: { products: Product[]; timestamp: number } | null = null;
  private readonly CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

  static getInstance(): ShopifyService {
    if (!ShopifyService.instance) {
      ShopifyService.instance = new ShopifyService();
    }
    return ShopifyService.instance;
  }

  private async fetchProductsFromShopify(): Promise<Product[]> {
    if (!SHOPIFY_DOMAIN || !SHOPIFY_ACCESS_TOKEN) {
      throw new Error('Shopify credentials not configured');
    }

    const query = `
      query getProducts($first: Int!) {
        products(first: $first) {
          edges {
            node {
              id
              title
              handle
              descriptionHtml
              vendor
              productType
              tags
              images(first: 10) {
                edges {
                  node {
                    id
                    src
                    altText
                  }
                }
              }
              variants(first: 50) {
                edges {
                  node {
                    id
                    title
                    price {
                      amount
                      currencyCode
                    }
                    compareAtPrice {
                      amount
                      currencyCode
                    }
                    sku
                    quantityAvailable
                    availableForSale
                  }
                }
              }
            }
          }
        }
      }
    `;

    const variables = {
      first: 50 // Adjust this number based on how many products you want to fetch
    };

    try {
      console.log('Fetching products from Shopify...');
      
      const response = await fetch(`https://${SHOPIFY_DOMAIN}/api/2024-04/graphql.json`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Shopify-Storefront-Access-Token': SHOPIFY_ACCESS_TOKEN,
        },
        body: JSON.stringify({
          query,
          variables
        })
      });

      if (!response.ok) {
        throw new Error(`Shopify API error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();

      if (data.errors) {
        throw new Error(`Shopify GraphQL errors: ${JSON.stringify(data.errors)}`);
      }

      const products = data.data.products.edges.map((edge: any, index: number) => {
        const product = edge.node;
        
        // Extract images
        const images = product.images.edges.map((imgEdge: any) => ({
          id: imgEdge.node.id,
          src: imgEdge.node.src,
          alt: imgEdge.node.altText || product.title
        }));

        // Extract variants
        const variants = product.variants.edges.map((variantEdge: any) => ({
          id: variantEdge.node.id.replace('gid://shopify/ProductVariant/', ''),
          title: variantEdge.node.title,
          price: parseFloat(variantEdge.node.price.amount),
          compareAtPrice: variantEdge.node.compareAtPrice ? parseFloat(variantEdge.node.compareAtPrice.amount) : null,
          sku: variantEdge.node.sku || '',
          inventoryQuantity: variantEdge.node.quantityAvailable || 0,
          available: variantEdge.node.availableForSale
        }));

        // Extract sizes from variant titles (common pattern: "Size / Color" or just "Size")
        const sizes = variants.map(variant => {
          const title = variant.title;
          // Handle common size patterns
          if (title === 'Default Title') return 'M'; // Default for products with no variants
          
          // Extract size from patterns like "Small", "S", "Small / Red", etc.
          const sizeMatch = title.match(/\b(XXS|XS|S|M|L|XL|XXL|XXXL|2XL|3XL|4XL|Small|Medium|Large|Extra Large)\b/i);
          if (sizeMatch) {
            const size = sizeMatch[1].toUpperCase();
            // Normalize size names
            switch (size) {
              case 'SMALL': return 'S';
              case 'MEDIUM': return 'M';
              case 'LARGE': return 'L';
              case 'EXTRA LARGE': return 'XL';
              default: return size;
            }
          }
          
          // If no standard size found, use the variant title as is
          return title;
        });

        // Remove duplicates and sort sizes
        const uniqueSizes = [...new Set(sizes)];
        const sizeOrder = ['XXS', 'XS', 'S', 'M', 'L', 'XL', 'XXL', '2XL', '3XL', '4XL'];
        const sortedSizes = uniqueSizes.sort((a, b) => {
          const aIndex = sizeOrder.indexOf(a);
          const bIndex = sizeOrder.indexOf(b);
          if (aIndex === -1 && bIndex === -1) return a.localeCompare(b);
          if (aIndex === -1) return 1;
          if (bIndex === -1) return -1;
          return aIndex - bIndex;
        });

        // Determine sport and team from tags, product type, or vendor
        const tags = product.tags || [];
        const productType = product.productType || '';
        const vendor = product.vendor || '';
        
        let sport = 'Sports';
        let team = vendor;

        // Try to determine sport from tags or product type
        const sportKeywords = {
          'Basketball': ['basketball', 'nba', 'ncaa basketball'],
          'Football': ['football', 'nfl', 'ncaa football'],
          'Baseball': ['baseball', 'mlb', 'ncaa baseball'],
          'Hockey': ['hockey', 'nhl'],
          'Soccer': ['soccer', 'football', 'mls', 'fifa'],
          'Tennis': ['tennis'],
          'Golf': ['golf']
        };

        for (const [sportName, keywords] of Object.entries(sportKeywords)) {
          if (keywords.some(keyword => 
            tags.some((tag: string) => tag.toLowerCase().includes(keyword)) ||
            productType.toLowerCase().includes(keyword) ||
            product.title.toLowerCase().includes(keyword)
          )) {
            sport = sportName;
            break;
          }
        }

        // Try to extract team name from title or tags
        const teamKeywords = [
          'Lakers', 'Warriors', 'Bulls', 'Celtics', 'Heat', 'Nets', 'Knicks',
          'Yankees', 'Red Sox', 'Dodgers', 'Giants', 'Cubs', 'Astros',
          'Chiefs', 'Cowboys', 'Patriots', 'Packers', 'Steelers', 'Rams'
        ];

        for (const teamName of teamKeywords) {
          if (product.title.toLowerCase().includes(teamName.toLowerCase()) ||
              tags.some((tag: string) => tag.toLowerCase().includes(teamName.toLowerCase()))) {
            team = teamName;
            break;
          }
        }

        // Get price information
        const baseVariant = variants[0] || {};
        const price = baseVariant.price || 0;
        const compareAtPrice = baseVariant.compareAtPrice;
        const salePrice = compareAtPrice && compareAtPrice > price ? price : undefined;
        const regularPrice = salePrice ? compareAtPrice : price;

        return {
          id: index + 1, // Sequential ID for internal use
          name: product.title,
          team: team,
          sport: sport,
          price: regularPrice,
          salePrice: salePrice,
          image: images[0]?.src || 'https://images.pexels.com/photos/358042/pexels-photo-358042.jpeg',
          rating: 4.5, // Default rating since Shopify doesn't provide this
          sizes: sortedSizes.length > 0 ? sortedSizes : ['S', 'M', 'L', 'XL'],
          description: product.descriptionHtml?.replace(/<[^>]*>/g, '') || '', // Strip HTML tags
          shopifyId: product.id,
          handle: product.handle,
          vendor: product.vendor,
          productType: product.productType,
          tags: product.tags.join(', '),
          variants: variants,
          images: images
        };
      });

      console.log(`Successfully fetched ${products.length} products from Shopify`);
      return products;

    } catch (error) {
      console.error('Error fetching products from Shopify:', error);
      throw error;
    }
  }

  async getProducts(): Promise<Product[]> {
    // Check cache first
    if (this.cache && Date.now() - this.cache.timestamp < this.CACHE_DURATION) {
      return this.cache.products;
    }

    // Try Shopify first
    try {
      const shopifyProducts = await this.fetchProductsFromShopify();
      
      // Update cache
      this.cache = {
        products: shopifyProducts,
        timestamp: Date.now(),
      };

      return shopifyProducts;
    } catch (shopifyError) {
      console.warn('Shopify fetch failed, trying Supabase:', shopifyError);
      
      // Try Supabase as fallback
      try {
        const { data: products, error } = await supabase
          .from('products')
          .select('*');

        if (error) {
          console.warn('Supabase error, falling back to mock data:', error.message);
          return this.getFallbackProducts();
        }

        if (!products || products.length === 0) {
          console.warn('No products found in Supabase, using mock data');
          return this.getFallbackProducts();
        }

        // Transform Supabase data to match our Product interface
        const transformedProducts: Product[] = products.map(product => ({
          id: product.id,
          name: product.name || 'Unknown Product',
          team: product.team || 'Unknown Team',
          sport: product.sport || 'Unknown Sport',
          price: product.price || 0,
          salePrice: product.sale_price || undefined,
          image: product.image || 'https://images.pexels.com/photos/358042/pexels-photo-358042.jpeg',
          rating: product.rating || 4.0,
          sizes: product.sizes || ['S', 'M', 'L', 'XL'],
          description: product.description,
          shopifyId: product.shopify_id,
          handle: product.handle,
          vendor: product.vendor,
          productType: product.product_type,
          tags: product.tags,
          variants: product.variants,
          images: product.images
        }));

        // Update cache
        this.cache = {
          products: transformedProducts,
          timestamp: Date.now(),
        };

        return transformedProducts;
      } catch (supabaseError) {
        console.error('Error fetching products from Supabase:', supabaseError);
        return this.getFallbackProducts();
      }
    }
  }

  private getFallbackProducts(): Product[] {
    console.log('Using fallback mock data');
    
    // Update cache with mock data
    this.cache = {
      products: mockProducts,
      timestamp: Date.now(),
    };

    return mockProducts;
  }

  async getProduct(id: number): Promise<Product | null> {
    const products = await this.getProducts();
    return products.find(p => p.id === id) || null;
  }

  async getProductsByTeam(team: string): Promise<Product[]> {
    const products = await this.getProducts();
    return products.filter(product => 
      product.team.toLowerCase().includes(team.toLowerCase())
    );
  }

  async getProductsBySport(sport: string): Promise<Product[]> {
    const products = await this.getProducts();
    return products.filter(product => 
      product.sport.toLowerCase() === sport.toLowerCase()
    );
  }

  async searchProducts(query: string): Promise<Product[]> {
    const products = await this.getProducts();
    const lowercaseQuery = query.toLowerCase();
    return products.filter(product =>
      product.name.toLowerCase().includes(lowercaseQuery) ||
      product.team.toLowerCase().includes(lowercaseQuery) ||
      product.sport.toLowerCase().includes(lowercaseQuery) ||
      (product.tags && product.tags.toLowerCase().includes(lowercaseQuery))
    );
  }

  clearCache(): void {
    this.cache = null;
  }
}

export const shopifyService = ShopifyService.getInstance();