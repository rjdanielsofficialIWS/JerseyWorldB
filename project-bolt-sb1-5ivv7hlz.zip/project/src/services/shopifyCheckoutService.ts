import { CartItem } from '../types';

const SHOPIFY_DOMAIN = import.meta.env.VITE_SHOPIFY_STOREFRONT_DOMAIN;
const SHOPIFY_ACCESS_TOKEN = import.meta.env.VITE_SHOPIFY_STOREFRONT_ACCESS_TOKEN;

export interface ShopifyCheckoutResponse {
  webUrl: string;
  id: string;
}

export class ShopifyCheckoutService {
  private static instance: ShopifyCheckoutService;

  static getInstance(): ShopifyCheckoutService {
    if (!ShopifyCheckoutService.instance) {
      ShopifyCheckoutService.instance = new ShopifyCheckoutService();
    }
    return ShopifyCheckoutService.instance;
  }

  async createCheckout(cartItems: CartItem[]): Promise<ShopifyCheckoutResponse> {
    if (!SHOPIFY_DOMAIN || !SHOPIFY_ACCESS_TOKEN) {
      throw new Error('Shopify configuration is missing. Please check your environment variables.');
    }

    // Filter out items without shopifyVariantId and map to line items
    const lineItems = cartItems
      .filter(item => item.shopifyVariantId)
      .map(item => ({
        variantId: `gid://shopify/ProductVariant/${item.shopifyVariantId}`,
        quantity: item.quantity
      }));

    if (lineItems.length === 0) {
      throw new Error('No valid items found for checkout. Please ensure products have valid variant IDs.');
    }

    const mutation = `
      mutation checkoutCreate($input: CheckoutCreateInput!) {
        checkoutCreate(input: $input) {
          checkout {
            id
            webUrl
            totalPriceV2 {
              amount
              currencyCode
            }
            lineItems(first: 250) {
              edges {
                node {
                  title
                  quantity
                }
              }
            }
          }
          checkoutUserErrors {
            field
            message
          }
        }
      }
    `;

    const variables = {
      input: {
        lineItems: lineItems
      }
    };

    try {
      console.log('Creating Shopify checkout with items:', lineItems);

      const response = await fetch(`https://${SHOPIFY_DOMAIN}/api/2024-04/graphql.json`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Shopify-Storefront-Access-Token': SHOPIFY_ACCESS_TOKEN,
        },
        body: JSON.stringify({
          query: mutation,
          variables: variables
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      console.log('Shopify checkout response:', data);

      if (data.errors) {
        throw new Error(`GraphQL errors: ${JSON.stringify(data.errors)}`);
      }

      const { checkoutCreate } = data.data;

      if (checkoutCreate.checkoutUserErrors && checkoutCreate.checkoutUserErrors.length > 0) {
        const errorMessages = checkoutCreate.checkoutUserErrors.map((error: any) => error.message).join(', ');
        throw new Error(`Checkout creation failed: ${errorMessages}`);
      }

      if (!checkoutCreate.checkout) {
        throw new Error('Failed to create checkout - no checkout object returned');
      }

      return {
        webUrl: checkoutCreate.checkout.webUrl,
        id: checkoutCreate.checkout.id
      };
    } catch (error) {
      console.error('Error creating Shopify checkout:', error);
      throw error;
    }
  }

  async addToCheckout(checkoutId: string, lineItems: Array<{ variantId: string; quantity: number }>): Promise<ShopifyCheckoutResponse> {
    const mutation = `
      mutation checkoutLineItemsAdd($checkoutId: ID!, $lineItems: [CheckoutLineItemInput!]!) {
        checkoutLineItemsAdd(checkoutId: $checkoutId, lineItems: $lineItems) {
          checkout {
            id
            webUrl
          }
          checkoutUserErrors {
            field
            message
          }
        }
      }
    `;

    const variables = {
      checkoutId,
      lineItems
    };

    try {
      const response = await fetch(`https://${SHOPIFY_DOMAIN}/api/2024-04/graphql.json`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Shopify-Storefront-Access-Token': SHOPIFY_ACCESS_TOKEN,
        },
        body: JSON.stringify({
          query: mutation,
          variables: variables
        })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.errors) {
        throw new Error(`GraphQL errors: ${JSON.stringify(data.errors)}`);
      }

      const { checkoutLineItemsAdd } = data.data;

      if (checkoutLineItemsAdd.checkoutUserErrors && checkoutLineItemsAdd.checkoutUserErrors.length > 0) {
        const errorMessages = checkoutLineItemsAdd.checkoutUserErrors.map((error: any) => error.message).join(', ');
        throw new Error(`Failed to add items to checkout: ${errorMessages}`);
      }

      return {
        webUrl: checkoutLineItemsAdd.checkout.webUrl,
        id: checkoutLineItemsAdd.checkout.id
      };
    } catch (error) {
      console.error('Error adding items to checkout:', error);
      throw error;
    }
  }
}

export const shopifyCheckoutService = ShopifyCheckoutService.getInstance();