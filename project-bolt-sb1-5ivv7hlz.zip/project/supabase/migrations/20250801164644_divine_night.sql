/*
  # Create products table for Jersey World B

  1. New Tables
    - `products`
      - `id` (bigint, primary key, auto-increment)
      - `name` (text, product name)
      - `team` (text, team name)
      - `sport` (text, sport category)
      - `price` (numeric, regular price)
      - `sale_price` (numeric, optional sale price)
      - `image` (text, main product image URL)
      - `rating` (numeric, product rating)
      - `sizes` (text array, available sizes)
      - `description` (text, product description)
      - `shopify_id` (text, Shopify product ID)
      - `handle` (text, Shopify product handle)
      - `vendor` (text, product vendor)
      - `product_type` (text, Shopify product type)
      - `tags` (text, product tags)
      - `variants` (jsonb, Shopify variants data)
      - `images` (jsonb, product images data)
      - `created_at` (timestamptz, creation timestamp)
      - `updated_at` (timestamptz, update timestamp)

  2. Security
    - Enable RLS on `products` table
    - Add policy for public read access (products are publicly viewable)
    - Add policy for authenticated users to manage products (admin functionality)

  3. Indexes
    - Index on sport for filtering
    - Index on team for filtering
    - Index on shopify_id for lookups
*/

CREATE TABLE IF NOT EXISTS products (
  id bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  name text NOT NULL,
  team text NOT NULL DEFAULT '',
  sport text NOT NULL DEFAULT 'Sports',
  price numeric(10,2) NOT NULL DEFAULT 0,
  sale_price numeric(10,2),
  image text NOT NULL DEFAULT '',
  rating numeric(3,2) NOT NULL DEFAULT 4.0,
  sizes text[] NOT NULL DEFAULT ARRAY['S', 'M', 'L', 'XL'],
  description text DEFAULT '',
  shopify_id text,
  handle text,
  vendor text DEFAULT '',
  product_type text DEFAULT '',
  tags text DEFAULT '',
  variants jsonb DEFAULT '[]'::jsonb,
  images jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE products ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access (anyone can view products)
CREATE POLICY "Products are publicly readable"
  ON products
  FOR SELECT
  TO public
  USING (true);

-- Create policy for authenticated users to insert/update products
CREATE POLICY "Authenticated users can manage products"
  ON products
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_products_sport ON products(sport);
CREATE INDEX IF NOT EXISTS idx_products_team ON products(team);
CREATE INDEX IF NOT EXISTS idx_products_shopify_id ON products(shopify_id);
CREATE INDEX IF NOT EXISTS idx_products_price ON products(price);

-- Create function to automatically update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger to automatically update updated_at
CREATE TRIGGER update_products_updated_at
  BEFORE UPDATE ON products
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();